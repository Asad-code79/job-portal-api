package com.firstProject.demo.Company.service;

import com.firstProject.demo.Company.Company;
import com.firstProject.demo.Company.repo.CompanyRepository;
import com.firstProject.demo.Job.model.Job;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompanyService {
    @Autowired
    private CompanyRepository companyRepository;

    public List<com.firstProject.demo.Company.Company> getAllCompanies(){
        return companyRepository.findAll();
    }

    public boolean updateCompany(Company company, Long id){
        Optional<Company> optionalCompany = companyRepository.findById(id);
        if (optionalCompany.isPresent()) {
            Company company1 = optionalCompany.get();
            company1.setName(company.getName());
            company1.setDescription(company.getDescription());
            companyRepository.save(company1);
            return true;
        }else {
            return false;
        }
    }
    public void createCompany(Company company){
        companyRepository.save(company);
    }
    public boolean deleteCompanyById(Long id){
        try {
            companyRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }

    }

    // Service
    public Company getCompanyById(Long id) {
        return companyRepository.findById(id).orElse(null);
    }


}
