package com.firstProject.demo.Job.service;

import com.firstProject.demo.Job.model.Job;
import com.firstProject.demo.Job.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobService {
    //List<Job> jobs = new ArrayList<>();
    @Autowired
    JobRepository jobRepository;

    public List<Job> findAll(){
        return jobRepository.findAll();
    }

    public String addJob(Job job){

        jobRepository.save(job);
        return "Job added successfully";
    }

    public Job getJobById(Long id) {
       return jobRepository.findById(id).orElse(null);
    }

    public Boolean deleteJobById(Long id) {
        try {
            jobRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }
    //public Job deleteJobById(Long id) {
    //    for (Job job : jobs) {
    //        if (job.getId().equals(id)) {
    //            jobs.remove(job);
    //            return job; // return the deleted job
    //        }
    //    }
    //    return null; // not found
    //}
    public boolean updateJob(Long id, Job updatedJob) {
        Optional<Job> optionalJob = jobRepository.findById(id);
            if (optionalJob.isPresent()) {
                Job job = optionalJob.get();
                job.setTitle(updatedJob.getTitle());
                job.setDescription(updatedJob.getDescription());
                job.setMinSalary(updatedJob.getMinSalary());
                job.setMaxSalary(updatedJob.getMaxSalary());
                job.setLocation(updatedJob.getLocation());
                jobRepository.save(job);
                return true;
            }
        return false;
    }

}
